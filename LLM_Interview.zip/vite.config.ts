/*
 * @Author: machao machao@shdata.com
 * @Date: 2023-07-26 13:30:02
 * @LastEditors: machao machao@shdata.com
 * @LastEditTime: 2023-11-22 14:47:46
 * @FilePath: \shdata_enlightenment_ai_lcdp_frontend\AICHAT\vite.config.ts
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
import path from "path";
import type { PluginOption } from "vite";
import { defineConfig, loadEnv } from "vite";
import vue from "@vitejs/plugin-vue";
import { VitePWA } from "vite-plugin-pwa";

function setupPlugins(env: ImportMetaEnv): PluginOption[] {
	return [
		vue(),
		env.VITE_GLOB_APP_PWA === "true" &&
			VitePWA({
				injectRegister: "auto",
				manifest: {
					name: "chatGPT",
					short_name: "chatGPT",
					icons: [
						{ src: "pwa-192x192.png", sizes: "192x192", type: "image/png" },
						{ src: "pwa-512x512.png", sizes: "512x512", type: "image/png" },
					],
				},
			}),
	];
}

export default defineConfig((env) => {
	const viteEnv = loadEnv(env.mode, process.cwd()) as unknown as ImportMetaEnv;

	return {
		resolve: {
			alias: {
				"@": path.resolve(process.cwd(), "src"),
			},
		},
		plugins: setupPlugins(viteEnv),
		server: {
			host: "0.0.0.0",
			port: 15400,
			open: false,
			proxy: {
				"/apiStream": {
					target: viteEnv.VITE_APP_API_STREAM_URL,
          // target:'http://192.168.20.73:18800/',
          // target:'http://192.168.20.73:10016/',
					changeOrigin: true, // 允许跨域
					rewrite: (path) => path.replace("/apiStream/", "/"),
				},
				"/susr": {
					target: viteEnv.VITE_APP_API_AUTH_URL,
					changeOrigin: true,
					rewrite: (path) => path.replace("/susr/", "/"),
				},
				"/sqacp": {
					target: viteEnv.VITE_APP_API_ROBOT_URL,
          // target:'http://192.168.20.94:18800/',
					changeOrigin: true,
					rewrite: (path) => path.replace("/sqacp/", "/"),
				},
				"/spost": {
					target: viteEnv.VITE_APP_API_LOG_URL,
					changeOrigin: true,
					rewrite: (path) => path.replace("/spost/", "/"),
				},
			},
		},
		build: {
			reportCompressedSize: false,
			sourcemap: false,
			commonjsOptions: {
				ignoreTryCatch: false,
			},
		},
	};
});
