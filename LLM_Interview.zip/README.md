# 聊天终端

## Project setup 安装依赖包
```
npm install
npm install --legacy-peer-deps (忽略依赖版本冲突)
```

### Compiles and hot-reloads for development 启动开发环境
```
npm run dev
```

### Compiles and minifies for production 打包生成文件
```
npm run build
```
