/*
 * @Author: machao machao@shdata.com
 * @Date: 2023-07-26 13:30:02
 * @LastEditors: machao machao@shdata.com
 * @LastEditTime: 2023-09-07 16:45:17
 * @FilePath: \shdata_enlightenment_ai_lcdp_frontend\AICHAT\src\utils\request\axios.ts
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
import axios, { type AxiosResponse } from 'axios'
import { useAuthStore } from '@/store'

const service = axios.create()

service.interceptors.request.use(
  (config) => {
    const token = useAuthStore().token
    if (token)
      config.headers.Authorization = `Bearer ${token}`
    return config
  },
  (error) => {
    return Promise.reject(error.response)
  },
)

service.interceptors.response.use(
  (response: AxiosResponse): AxiosResponse => {
    console.log(response)
    if (response.status === 200)
      return response

    throw new Error(response.status.toString())
  },
  (error) => {
    return Promise.reject(error)
  },
)

export default service
