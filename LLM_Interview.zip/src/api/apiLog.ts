/*
 * @Author: machao machao@shdata.com
 * @Date: 2023-08-25 15:40:04
 * @LastEditors: machao machao@shdata.com
 * @LastEditTime: 2023-11-22 14:04:18
 * @FilePath: \shdata_enlightenment_ai_lcdp_frontend\AIROBOT\src\api\request18300.js
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
import customRequest from "./request";
const request = customRequest({
	baseURL: import.meta.env.VITE_GLOB_APILOG_URL,
});
const apiLog: any = {};
//chatBotInstanceInitController/getPageableChatBotInstance
apiLog.handleHardQuestions = (data: any) => {
	return request({
		url: "/questionAnalysis/handleHardQuestions",
		method: "post",
		data: data,
	});
};
// logManagement/saveSessionLog 保存单条会话
apiLog.saveSessionLog = (params: any, data: any) => {
	return request({
		url: "/logManagement/saveSessionLog",
		method: "post",
		params,
		data: data,
	});
};

// feedbackProcess/handleAnswerResponse
apiLog.handleAnswerResponse = (data: any) => {
	return request({
		url: "/feedbackProcess/handleAnswerResponse",
		method: "post",
		data: data,
	});
};

// logManagement/getSessionLogs 根据chatId获取会话日志列表（已根据时间排序）
apiLog.getSessionLogs = (params: any) => {
	return request({
		url: "/logManagement/getSessionLogs",
		method: "get",
		params,
	});
};
export default apiLog;
