/*
 * @Author: machao machao@shdata.com
 * @Date: 2023-07-26 13:30:02
 * @LastEditors: machao machao@shdata.com
 * @LastEditTime: 2023-11-22 15:02:18
 * @FilePath: \shdata_enlightenment_ai_lcdp_frontend\AICHAT\src\store\modules\auth\index.ts
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
import { defineStore } from "pinia";
import { getToken, removeToken, setToken } from "./helper";
import { store } from "@/store";
import { fetchSession } from "@/api";
import apiAuth from "@/api/apiAuth";
import { useUserStore } from "@/store";

interface SessionResponse {
	auth: boolean;
	model: "ChatGPTAPI" | "ChatGPTUnofficialProxyAPI";
}

export interface AuthState {
	token: string | undefined;
	session: SessionResponse | null;
	auth: boolean;
}

export const useAuthStore = defineStore("auth-store", {
	state: (): AuthState => ({
		token: getToken(),
		session: null,
		auth: false,
	}),

	getters: {
		isChatGPTAPI(state): boolean {
			return state.session?.model === "ChatGPTAPI";
		},
	},

	actions: {
		async getSession() {
			try {
				const { data } = await fetchSession<SessionResponse>();
				this.session = { ...data };
				return Promise.resolve(data);
			} catch (error) {
				return Promise.reject(error);
			}
		},
		async checkToken(token: string | undefined) {
			const userStore = useUserStore();
			try {
				let res = await apiAuth.checkToken({ token });
				this.auth = res.status !== "UNAUTH";
				userStore.updateUserInfo({ name: res.user_name }); // 修改用户名
				return Promise.resolve(this.auth);
			} catch (error) {
				return Promise.reject(error);
			}
		},
		setToken(token: string) {
			this.token = token;
			setToken(token);
		},

		removeToken() {
			this.token = undefined;
			removeToken();
		},
	},
});

export function useAuthStoreWithout() {
	return useAuthStore(store);
}
