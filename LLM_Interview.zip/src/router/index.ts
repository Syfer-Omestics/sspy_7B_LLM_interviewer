/*
 * @Author: machao machao@shdata.com
 * @Date: 2023-06-12 17:05:02
 * @LastEditors: machao machao@shdata.com
 * @LastEditTime: 2023-11-22 14:53:35
 * @FilePath: \shdata_enlightenment_ai_lcdp_frontend\AICHAT\src\router\index.ts
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
import type { App } from "vue";
import type { RouteRecordRaw } from "vue-router";
import { createRouter, createWebHashHistory } from "vue-router";
import { setupPageGuard } from "./permission";
import { ChatLayout } from "@/views/chat/layout";

const isProd = process.env.NODE_ENV === 'production';

const routes: RouteRecordRaw[] = [
	{
		path: "/",
		name: "Root",
		component: ChatLayout,
		redirect: "/chat",
		children: [
			{
				path: "/chat/:uuid?",
				name: "Chat",
				component: () => import("@/views/chat/index.vue"),
			},
		],
	},
	{
		path: "/404",
		name: "404",
		component: () => import("@/views/exception/404/index.vue"),
	},

	{
		path: "/500",
		name: "500",
		component: () => import("@/views/exception/500/index.vue"),
		beforeEnter: (to, from) => {
			// reject the navigation
			let host = window.location.host.split(":")[0];
			window.location.href = "http://" + host + ":15000/#/login?redirect=aichat";
			return false;
		},
	},

	{
		path: "/:pathMatch(.*)*",
		name: "notFound",
		redirect: "/404",
	},
];

export const router = createRouter({
	history: createWebHashHistory(),
	routes,
	scrollBehavior: () => ({ left: 0, top: 0 }),
});

isProd && setupPageGuard(router);

export async function setupRouter(app: App) {
	app.use(router);
	await router.isReady();
}
