/*
 * @Author: machao machao@shdata.com
 * @Date: 2023-07-14 14:58:34
 * @LastEditors: machao machao@shdata.com
 * @LastEditTime: 2023-11-22 11:28:19
 * @FilePath: \shdata_enlightenment_ai_lcdp_frontend\AICHAT\src\main.ts
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
import { createApp } from "vue";
import App from "./App.vue";
import { setupI18n } from "./locales";
import { setupAssets, setupScrollbarStyle } from "./plugins";
import { setupStore } from "./store";
import { setupRouter } from "./router";
import "viewerjs/dist/viewer.css";
import VueViewer from "v-viewer";

async function bootstrap() {
	const app = createApp(App);
	setupAssets();

	setupScrollbarStyle();

	setupStore(app);

	setupI18n(app);

	app.use(VueViewer);

	await setupRouter(app);

	app.mount("#app");
}

bootstrap();
