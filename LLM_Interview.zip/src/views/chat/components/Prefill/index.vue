<!--
 * @Author: machao machao@shdata.com
 * @Date: 2023-10-16 16:07:18
 * @LastEditors: machao machao@shdata.com
 * @LastEditTime: 2023-10-17 10:38:25
 * @FilePath: \shdata_enlightenment_ai_lcdp_frontend\AICHAT\src\views\chat\components\Prefill\index.vue
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
-->
<script lang="ts" setup>
import { computed, nextTick } from "vue";
import { HoverButton, SvgIcon } from "@/components/common";
import { useAppStore, useChatStore } from "@/store";

interface Props {
	formUrl: string;
}

interface Emit {
	(ev: "export"): void;
	(ev: "toggleUsingContext"): void;
}

defineProps<Props>();

const emit = defineEmits<Emit>();

const appStore = useAppStore();
const chatStore = useChatStore();

const collapsed = computed(() => appStore.siderCollapsed);

function toggleUsingContext() {
	emit("toggleUsingContext");
}
</script>

<template>
	<div className="text-center w-full h-full">
		<iframe
			name="chatBot"
			:src="formUrl"
			style="width: 100%; height: 100%; border: none"
		></iframe>
	</div>
</template>
