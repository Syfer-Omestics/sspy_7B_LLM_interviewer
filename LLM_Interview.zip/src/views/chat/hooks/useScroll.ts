/*
 * @Author: machao machao@shdata.com
 * @Date: 2023-07-14 14:58:34
 * @LastEditors: machao machao@shdata.com
 * @LastEditTime: 2023-11-22 15:52:38
 * @FilePath: \shdata_enlightenment_ai_lcdp_frontend\AICHAT\src\views\chat\hooks\useScroll.ts
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
import type { Ref } from "vue";
import { nextTick, ref } from "vue";

type ScrollElement = HTMLDivElement | null;

interface ScrollReturn {
	scrollRef: Ref<ScrollElement>;
	scrollToBottom: () => Promise<void>;
	scrollToTop: () => Promise<void>;
	scrollToBottomIfAtBottom: () => Promise<void>;
	scrollToPosition: (height: number) => Promise<void>;
}

export function useScroll(): ScrollReturn {
	const scrollRef = ref<ScrollElement>(null);

	const scrollToBottom = async () => {
		await nextTick();
		// setTimeout(() => {
			if (scrollRef.value)
				scrollRef.value.scrollTop = scrollRef.value.scrollHeight;
		// }, 300);
	};

	const scrollToTop = async () => {
		await nextTick();
		if (scrollRef.value) scrollRef.value.scrollTop = 0;
	};

	const scrollToBottomIfAtBottom = async () => {
		await nextTick();
		if (scrollRef.value) {
			const threshold = 100; // 阈值，表示滚动条到底部的距离阈值
			const distanceToBottom =
				scrollRef.value.scrollHeight -
				scrollRef.value.scrollTop -
				scrollRef.value.clientHeight;
			if (distanceToBottom <= threshold)
				scrollRef.value.scrollTop = scrollRef.value.scrollHeight;
		}
	};

	const scrollToPosition = async (height: number) => {
		console.log(height);

		await nextTick();
		console.log(scrollRef.value);

		if (scrollRef.value) scrollRef.value.scrollTop = 200;
	};
	return {
		scrollRef,
		scrollToBottom,
		scrollToTop,
		scrollToBottomIfAtBottom,
		scrollToPosition,
	};
}
