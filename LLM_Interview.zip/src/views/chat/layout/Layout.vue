<!--
 * @Author: machao machao@shdata.com
 * @Date: 2023-07-26 13:30:02
 * @LastEditors: machao machao@shdata.com
 * @LastEditTime: 2023-11-13 09:55:56
 * @FilePath: \shdata_enlightenment_ai_lcdp_frontend\AICHAT\src\views\chat\layout\Layout.vue
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
-->
<script setup lang="ts">
import { computed } from "vue";
import { NLayout, NLayoutContent } from "naive-ui";
import { useRouter, useRoute } from "vue-router";
import Sider from "./sider/index.vue";
import Permission from "./Permission.vue";
import { useBasicLayout } from "@/hooks/useBasicLayout";
import { useAppStore, useAuthStore, useChatStore } from "@/store";

const router = useRouter();
const route = useRoute();
const appStore = useAppStore();
const chatStore = useChatStore();
const authStore = useAuthStore();

const { uuid } = route.params as { uuid: string };

if (uuid !== "log") {
  router.replace({ name: "Chat", params: { uuid: chatStore.active } });
}

const { isMobile } = useBasicLayout();

const collapsed = computed(() => appStore.siderCollapsed);

const needPermission = computed(
  () => !!authStore.session?.auth && !authStore.token
);
const showChapterList = computed(() => {
  const instanceInfo = chatStore.getChatHistoryByCurrentActive?.instanceInfo;
  const { knowledgeLearnType, usingLLM, strategyType,relatedChapterInstance } = instanceInfo;
  const isChapter = knowledgeLearnType === "CHAPTERS_LEARN";
  const containChapter = usingLLM && strategyType === "SINGLE_DOMAIN" && relatedChapterInstance;;
  return isChapter || containChapter;
});

const getMobileClass = computed(() => {
  if (isMobile.value) return ["rounded-none", "shadow-none"];
  return ["border", "rounded-md", "shadow-md", "dark:border-neutral-800"];
});

const getContainerClass = computed(() => {
  return [
    "h-full",
    { "pl-[260px]": !isMobile.value && !collapsed.value && uuid !== "log" },
    {
      "pl-[520px]":
        showChapterList.value &&
        !isMobile.value &&
        !collapsed.value &&
        uuid !== "log",
    },
  ];
});
</script>

<template>
  <div
    class="h-full dark:bg-[#24272e] transition-all"
    :class="[isMobile ? 'p-0' : 'p-4']"
  >
    <div class="h-full overflow-hidden" :class="getMobileClass">
      <NLayout class="z-40 transition" :class="getContainerClass" has-sider>
        <Sider v-if="uuid != 'log'" />
        <NLayoutContent class="h-full">
          <RouterView v-slot="{ Component, route }">
            <component :is="Component" :key="route.fullPath" />
          </RouterView>
        </NLayoutContent>
      </NLayout>
    </div>
    <Permission :visible="needPermission" />
  </div>
</template>
